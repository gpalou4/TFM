rm(list=ls())


### BIG QUESTION: WHAT IS SEX=1 OR SEX=2 FEMALE OR MALE?

# Read table with Sex and ID data from ALL FHS study (+7000 individuals)
df.sex <- read.table("/projects/regicor/Guille/TFM/methylation/phenotype/sex_age/phs000007.v25.pht003099.v3.p9.c1.vr_dates_2011_m_0689s.HMB-IRB-MDS_clean.txt",
                 header=T, stringsAsFactors = F, sep="\t")
# SEX=1 MALE, SEX=2 FEMALE
df.sex <- df.sex[,c("shareid","SEX")]
# Read table with ID from 450k methylation study (+2300 individuals)
df.ID <- read.table("/projects/regicor/Guille/TFM/methylation/phenotype/phs000724.v2.pht004247.v1.p9.c1.Framingham_DNA_Methylation_Sample_Attributes_II.HMB-IRB-MDS_clean.csv",
                    header=TRUE, stringsAsFactors = F, sep=",")
# Clean ID from Meth study (remove 724 from the ID, which is the accession number of the study)
df.ID$SAMPID <- substr(df.ID$SAMPID,1,nchar(df.ID$SAMPID)-4)
#vector <- vapply(df.ID$SAMPID, function(x) substr(x,1,nchar(x)-4),c(1:2567)) NO VA

# Rename colname for matching columns after
names(df.sex)[1] <- "SAMPID"

# Merge both dataframes based on the same named column of IDs
df.sex.ID <- merge(df.sex, df.ID, by = "SAMPID")

# Save the dataframe
write.csv(df.sex.ID, file="/projects/regicor/Guille/TFM/methylation/QC/4.sex/df_sex.csv", row.names = FALSE)

